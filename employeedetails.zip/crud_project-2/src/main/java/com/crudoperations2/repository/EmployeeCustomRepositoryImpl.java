package com.crudoperations2.repository;

import com.crudoperations2.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import java.time.LocalDate;
import java.util.List;

public class EmployeeCustomRepositoryImpl implements EmployeeCustomRepository {

    @Autowired
    private MongoTemplate mongoTemplate;

    @Override
    public List<Employee> searchEmployees(String name, String department, Integer age, Double salary, LocalDate startDate, LocalDate endDate) {
        Query query = new Query();

        if (name != null) {
            query.addCriteria(Criteria.where("name").is(name));
        }
        if (department != null) {
            query.addCriteria(Criteria.where("department").is(department));
        }
        if (age != null) {
            query.addCriteria(Criteria.where("age").is(age));
        }
        if (salary != null) {
            query.addCriteria(Criteria.where("salary").is(salary));
        }
        if (startDate != null && endDate != null) {
            query.addCriteria(Criteria.where("joiningDate").gte(startDate).lte(endDate));
        }

        return mongoTemplate.find(query, Employee.class);
    }
}