package com.crudoperations2.repository;

import java.time.LocalDate;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.crudoperations2.model.Employee;

@Repository
public interface EmployeeCustomRepository {
	List<Employee> searchEmployees(String name, String employeeId, Integer age, Double salary, LocalDate startDate, LocalDate endDate);
	}


