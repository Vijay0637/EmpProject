package com.crudoperations2.service;
import com.crudoperations2.model.Employee;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.crudoperations2.repository.EmployeeCustomRepository;
import com.crudoperations2.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class EmployeeService {
	private final EmployeeRepository employeeRepository;
    private final EmployeeCustomRepository employeeCustomRepository;

    public EmployeeService(EmployeeRepository employeeRepository,
                           @Qualifier("employeeCustomRepositoryImpl") EmployeeCustomRepository employeeCustomRepository) {
        this.employeeRepository = employeeRepository;
        this.employeeCustomRepository = employeeCustomRepository;
    }

	

    public Employee createEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    public Optional<Employee> getEmployeeById(String id) {
        return employeeRepository.findById(id);
    }

    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    public Employee updateEmployee(String id, Employee employeeDetails) {
        Optional<Employee> optionalEmployee = employeeRepository.findById(id);
        if (optionalEmployee.isPresent()) {
            Employee employee = optionalEmployee.get();
            employee.setName(employeeDetails.getName());
            employee.setAge(employeeDetails.getAge());
            employee.setEmployeeId(employeeDetails.getEmployeeId());
            employee.setSalary(employeeDetails.getSalary());
            employee.setDateOfJoining(employeeDetails.getDateOfJoining());
            return employeeRepository.save(employee);
        } else {
            return null;
        }
    }

    public void deleteEmployee(String id) {
        employeeRepository.deleteById(id);
    }
    public List<Employee> searchEmployees(String name, String employeeId, Integer age, Double salary, LocalDate startDate, LocalDate endDate) {
        return employeeCustomRepository.searchEmployees(name, employeeId, age, salary, startDate, endDate);
    }
    
 // Export employees to Excel
    public void exportEmployeesToExcel(OutputStream outputStream) throws IOException {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Employees");
            // Create header row
            Row headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("ID");
            headerRow.createCell(1).setCellValue("Name");
            headerRow.createCell(2).setCellValue("Age");
            headerRow.createCell(3).setCellValue("Salary");
            headerRow.createCell(4).setCellValue("Date of Joining");
            // Get employee data
            List<Employee> employees = getAllEmployees();
            // Populate data rows
            int rowNum = 1;
            for (Employee employee : employees) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(employee.getId());
                row.createCell(1).setCellValue(employee.getName());
                row.createCell(2).setCellValue(employee.getAge());
                row.createCell(3).setCellValue(employee.getSalary());
                row.createCell(4).setCellValue(employee.getDateOfJoining().toString());
            }
            // Write workbook to output stream
            workbook.write(outputStream);
        }
    }
}



