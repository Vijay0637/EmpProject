package com.crudoperations2.service;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.crudoperations2.model.Employee;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Service
public class ExcelService {

    @Autowired
    private MongoTemplate mongoTemplate;

    public void importEmployeesFromExcel(MultipartFile file) throws IOException {
        List<Employee> employees = new ArrayList<>();
        try (InputStream inputStream = file.getInputStream();
             Workbook workbook = new XSSFWorkbook(inputStream)) {

            Sheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rows = sheet.iterator();

            // Assuming first row is header
            if (rows.hasNext()) {
                rows.next();
            }

            while (rows.hasNext()) {
                Row row = rows.next();
                Employee employee = new Employee();

                Cell nameCell = row.getCell(0);
                if (nameCell != null) {
                    employee.setName(nameCell.getStringCellValue());
                }

                Cell ageCell = row.getCell(1);
                if (ageCell != null && ageCell.getCellType() == CellType.NUMERIC) {
                    employee.setAge((int) ageCell.getNumericCellValue());
                }

                Cell salaryCell = row.getCell(2);
                if (salaryCell != null && salaryCell.getCellType() == CellType.NUMERIC) {
                    employee.setSalary(salaryCell.getNumericCellValue());
                }

                Cell dateCell = row.getCell(3);
                if (dateCell != null) {
                    if (dateCell.getCellType() == CellType.NUMERIC) {
                        long epochDay = (long) dateCell.getNumericCellValue();
                        if (epochDay >= LocalDate.MIN.toEpochDay() && epochDay <= LocalDate.MAX.toEpochDay()) {
                            LocalDate localDate = LocalDate.ofEpochDay(epochDay);
                            employee.setDateOfJoining(localDate);
                        } else {
                            // Handle invalid epoch day value
                            System.out.println("Invalid value for EpochDay: " + epochDay);
                        }
                    } else {
                        // Handle non-numeric cell value
                        System.out.println("Non-numeric value found for date in row " + row.getRowNum());
                    }
                }

                employees.add(employee);
            }
        } 

        // Insert employees into MongoDB
        mongoTemplate.insertAll(employees);
    }
}